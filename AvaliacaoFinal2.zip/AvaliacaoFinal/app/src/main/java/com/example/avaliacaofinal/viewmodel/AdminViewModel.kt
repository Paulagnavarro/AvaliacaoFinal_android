package com.example.avaliacaofinal.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.avaliacaofinal.model.Usuario
import com.example.avaliacaofinal.repository.UsuarioRepository
import androidx.lifecycle.viewModelScope
import com.example.avaliacaofinal.model.Admin
import com.example.avaliacaofinal.repository.AdminRepository
import kotlinx.coroutines.launch

class AdminViewModel(private val adminRepository: AdminRepository) : ViewModel() {

    private val _admin = MutableLiveData<Admin?>()
    val admin: LiveData<Admin?> get() = _admin

    private val _todosAdmins = MutableLiveData<List<Admin>>()
    val todosAdmins: LiveData<List<Admin>> get() = _todosAdmins

    // Função para salvar um administrador
    fun salvarAdmin(admin: Admin) {
        viewModelScope.launch {
            val id = adminRepository.salvarAdmin(admin)
            // Se necessário, você pode realizar alguma ação após a inserção, como navegar para outra tela
        }
    }

    // Função para obter um administrador por username e senha
    fun getAdminByUsernameSenha(email: String, senha: String) {
        viewModelScope.launch {
            _admin.value = adminRepository.getAdminByEmailSenha(email, senha)
        }
    }

    // Função para obter todos os administradores
    fun getAllAdmins() {
        viewModelScope.launch {
            _todosAdmins.value = adminRepository.getAllAdmins()
        }
    }

    // Função para excluir um administrador
    fun deleteAdmin(admin: Admin) {
        viewModelScope.launch {
            adminRepository.deleteAdmin(admin)
        }
    }
}
