package com.example.avaliacaofinal.repository

import android.content.Context
import com.example.avaliacaofinal.model.Admin

class AdminRepository(context: Context) {

    val adminDAO = LivroDataBase.getInstace(context).getAdminDAO()

    fun salvarAdmin(admin: Admin): Long {
        return adminDAO.salvar(admin)
    }

    fun getAdminByEmailSenha(email: String, senha: String): Admin? {
        return adminDAO.getAdmin(email, senha)
    }

    fun getAdminById(id: Int): Admin? {
        return adminDAO.getAdmin(id)
    }

    fun getAllAdmins(): List<Admin> {
        return adminDAO.getAll()
    }

    fun deleteAdmin(admin: Admin) {
        adminDAO.delete(admin)
    }
}