package com.example.avaliacaofinal.repository

import android.content.Context
import com.example.avaliacaofinal.model.Livro

class LivroRepository(context: Context) {

    val dao = LivroDataBase.getInstace(context).getDAO()

    fun salvar(livro: Livro) : Boolean{
        return dao.salvar(livro) > 0
    }

    fun atualizar(livro: Livro) {
        dao.atualizar(livro)
    }

    fun deletar(livro: Livro){
        dao.deletar(livro)
    }

    fun getLivro(id: Int): Livro {
        return dao.getLivro(id)
    }

    fun getAll() : List<Livro> {
        return dao.getAll()
    }

}