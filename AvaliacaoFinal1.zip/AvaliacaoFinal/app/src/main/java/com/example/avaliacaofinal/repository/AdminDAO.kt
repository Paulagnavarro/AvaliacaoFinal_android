package com.example.avaliacaofinal.repository

import androidx.room.*
import com.example.avaliacaofinal.model.Admin
import com.example.avaliacaofinal.model.Usuario

@Dao
interface AdminDAO {

    @Insert
    fun salvar(admin: Admin): Long

    @Query("SELECT * FROM admin WHERE email = :email AND senha = :senha LIMIT 1")
    fun getAdmin(email: String, senha: String): Admin?

    @Query("SELECT * FROM admin WHERE id = :id")
    fun getAdmin(id: Int): Admin?

    @Query("SELECT * FROM admin")
    fun getAll(): List<Admin>

    @Delete
    fun delete(admin: Admin)
}