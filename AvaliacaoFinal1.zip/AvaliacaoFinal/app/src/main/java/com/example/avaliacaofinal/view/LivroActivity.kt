package com.example.avaliacaofinal.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.example.avaliacaofinal.R
import com.example.avaliacaofinal.databinding.ActivityLivroBinding
import com.example.avaliacaofinal.model.Livro
import com.example.avaliacaofinal.viewmodel.LivroViewModel

class LivroActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLivroBinding
    private lateinit var viewModel : LivroViewModel
    private lateinit var livro : Livro

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLivroBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this).get(LivroViewModel::class.java)

        setObservers()

        val id = intent.getIntExtra("id", 0)

        if(id == 0){
            finish()
        } else {
            viewModel.findLivro(id)
        }

        binding.btnConfirmar.setOnClickListener{
            val categoria  = binding.edtVerCategoria.text.toString()
            val ano = binding.edtVerAno.text.toString()
            val autor = binding.edtVerAutor.text.toString()

            if (viewModel.validarAntesDeAtualizar(livro.nomeLivro, categoria, ano, autor)){
                livro.categoria = categoria.toString()
                livro.ano = ano.toString()
                livro.autor = autor.toString()
                viewModel.atualizar(livro)
                finish()
            }
        }
    }
    fun setObservers(){
        viewModel.getLivroFromDB().observe(this){
            livro = it
            binding.txtVerNomeLivro.text = livro.nomeLivro
            binding.edtVerCategoria.setText(livro.categoria.toString())
            binding.edtVerAno.setText(livro.ano.toString())
            binding.edtVerAutor.setText(livro.autor.toString())
        }
        viewModel.getTxtToast().observe(this){
            Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
        }
    }
}