package com.example.avaliacaofinal.view.viewholder

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.avaliacaofinal.R

class LivroViewHolder(layout: View): RecyclerView.ViewHolder(layout) {

    var txtDadosLivro = layout.findViewById<TextView>(R.id.txtDadosLivro)
//    var txtCategoria = layout.findViewById<TextView>(R.id.txtCategoria)
//    var txtAno = layout.findViewById<TextView>(R.id.txtAno)
//    var txtAutor = layout.findViewById<TextView>(R.id.txtAutor)

}