package com.example.avaliacaofinal.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.avaliacaofinal.model.Usuario
import com.example.avaliacaofinal.repository.UsuarioRepository
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class UsuarioViewModel(private val usuarioRepository: UsuarioRepository) : ViewModel() {

    // LiveData para observar os resultados das operações
    private val _usuario = MutableLiveData<Usuario?>()
    val usuario: LiveData<Usuario?> get() = _usuario

    // LiveData para observar todos os usuários
    private val _todosUsuarios = MutableLiveData<List<Usuario>>()
    val todosUsuarios: LiveData<List<Usuario>> get() = _todosUsuarios

    // Função para salvar um usuário
    fun salvarUsuario(usuario: Usuario) {
        viewModelScope.launch {
            val id = usuarioRepository.salvarUsuario(usuario)
            // Se necessário, você pode realizar alguma ação após a inserção, como navegar para outra tela
        }
    }

    // Função para obter um usuário por email e senha
    fun getUsuarioByEmailSenha(email: String, senha: String) {
        viewModelScope.launch {
            _usuario.value = usuarioRepository.getUsuarioByEmailSenha(email, senha)
        }
    }

    // Função para obter todos os usuários
    fun getAllUsuarios() {
        viewModelScope.launch {
            _todosUsuarios.value = usuarioRepository.getAllUsuarios()
        }
    }

    // Função para excluir um usuário
    fun deleteUsuario(usuario: Usuario) {
        viewModelScope.launch {
            usuarioRepository.deleteUsuario(usuario)
        }
    }
}
