package com.example.avaliacaofinal.repository

import androidx.room.*
import com.example.avaliacaofinal.model.Usuario

@Dao
interface UsuarioDAO {

    @Insert
    fun salvar(usuario: Usuario): Long

    @Query("SELECT * FROM usuario WHERE email = :email AND senha = :senha LIMIT 1")
    fun getUsuario(email: String, senha: String): Usuario?

    @Query("SELECT * FROM usuario WHERE id = :id")
    fun getUsuario(id: Int): Usuario?

    @Query("SELECT * FROM usuario")
    fun getAll(): List<Usuario>

    @Delete
    fun delete(usuario: Usuario)
}
