package com.example.avaliacaofinal.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.avaliacaofinal.model.Usuario
import com.example.avaliacaofinal.repository.UsuarioRepository
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class UsuarioViewModel(private val usuarioRepository: UsuarioRepository) : ViewModel() {

    private val _usuario = MutableLiveData<Usuario?>()
    val usuario: LiveData<Usuario?> get() = _usuario

    private val _todosUsuarios = MutableLiveData<List<Usuario>>()
    val todosUsuarios: LiveData<List<Usuario>> get() = _todosUsuarios

    fun salvarUsuario(usuario: Usuario) {
        viewModelScope.launch {
            val id = usuarioRepository.salvarUsuario(usuario)
        }
    }

    fun getUsuarioByEmailSenha(email: String, senha: String) {
        viewModelScope.launch {
            _usuario.value = usuarioRepository.getUsuarioByEmailSenha(email, senha)
        }
    }

    fun getAllUsuarios() {
        viewModelScope.launch {
            _todosUsuarios.value = usuarioRepository.getAllUsuarios()
        }
    }

    fun deleteUsuario(usuario: Usuario) {
        viewModelScope.launch {
            usuarioRepository.deleteUsuario(usuario)
        }
    }
}
