package com.example.avaliacaofinal.model

class ValidarLivro {

    fun camposEmBranco(nomeHeroi : String, categoria: String, ano: String, autor: String) : Boolean{
        return nomeHeroi.isEmpty() || categoria.isEmpty() || ano.isEmpty() || autor.isEmpty()
    }

}