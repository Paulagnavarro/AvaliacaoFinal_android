package com.example.avaliacaofinal.model;

enum class TipoUsuario {
    Usuario,
    Admin
}

