package com.example.avaliacaofinal.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.example.avaliacaofinal.databinding.ActivityCadastroBinding
import com.example.avaliacaofinal.viewmodel.CadastroViewModel

class CadastroActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCadastroBinding
    private lateinit var viewModel: CadastroViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCadastroBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this).get(CadastroViewModel::class.java)
        setObservers()

        binding.btnSalvar.setOnClickListener {

            val nomeLivro = binding.edtNomeLivro.text.toString()
            val categoria = binding.edtCategoria.text.toString()
            val ano = binding.edtAno.text.toString()
            val autor = binding.edtAutor.text.toString()


            if(viewModel.salvar(nomeLivro, categoria, ano, autor)){
                finish()
            }
        }
    }

    fun setObservers(){
        viewModel.getTxtToast().observe(this){
            Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
        }
    }
}