package com.example.avaliacaofinal.repository

import android.content.Context
import com.example.avaliacaofinal.model.Usuario

class UsuarioRepository(context: Context) {

    val usuarioDAO = LivroDataBase.getInstace(context).getUsuarioDAO()

    fun salvarUsuario(usuario: Usuario): Long {
        return usuarioDAO.salvar(usuario)
    }

    fun getUsuarioByEmailSenha(email: String, senha: String): Usuario? {
        return usuarioDAO.getUsuario(email, senha)
    }

    fun getUsuarioById(id: Int): Usuario? {
        return usuarioDAO.getUsuario(id)
    }

    fun getAllUsuarios(): List<Usuario> {
        return usuarioDAO.getAll()
    }

    fun deleteUsuario(usuario: Usuario) {
        usuarioDAO.delete(usuario)
    }
}
