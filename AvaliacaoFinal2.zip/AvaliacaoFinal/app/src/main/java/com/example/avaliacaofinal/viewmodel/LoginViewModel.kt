package com.example.avaliacaofinal.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.avaliacaofinal.model.Admin
import com.example.avaliacaofinal.model.Usuario
import com.example.avaliacaofinal.repository.AdminRepository
import com.example.avaliacaofinal.repository.UsuarioRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class LoginViewModel(
    private val usuarioRepository: UsuarioRepository,
    private val adminRepository: AdminRepository
) : ViewModel() {

    private val _usuario = MutableLiveData<Usuario?>()
    val usuario: LiveData<Usuario?> get() = _usuario

    private val _admin = MutableLiveData<Admin?>()
    val admin: LiveData<Admin?> get() = _admin

    private val viewModelJob = Job()
    private val viewModelScope = CoroutineScope(Dispatchers.Main + viewModelJob)

    fun fazerLogin(email: String, senha: String, tipo: TipoUsuario) {
        viewModelScope.launch {
            when (tipo) {
                TipoUsuario.USUARIO -> _usuario.value = usuarioRepository.getUsuarioByEmailSenha(email, senha)
                TipoUsuario.ADMIN -> _admin.value = adminRepository.getAdminByEmailSenha(email, senha)
            }
        }
    }



    override fun onCleared() {
        super.onCleared()
        viewModelJob.cancel()
    }
}
