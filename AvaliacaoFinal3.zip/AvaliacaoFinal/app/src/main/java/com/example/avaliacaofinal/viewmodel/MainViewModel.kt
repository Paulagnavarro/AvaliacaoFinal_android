package com.example.avaliacaofinal.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.avaliacaofinal.model.Livro
import com.example.avaliacaofinal.repository.LivroRepository

class MainViewModel(application: Application): AndroidViewModel(application) {

    private var repository = LivroRepository(application.applicationContext)
    private var listViewModel = MutableLiveData<List<Livro>>()
    private var txtToast = MutableLiveData<String>()

    fun getListViewModel() : LiveData<List<Livro>> {
        return listViewModel
    }

    fun getTxtToast() : LiveData<String> {
        return txtToast
    }

    fun getListFromDB() {
        listViewModel.value = repository.getAll()
    }

    fun deletar(livro: Livro){
        repository.deletar(livro)
        txtToast.value = "Livro excluído!"
    }

}