package com.example.avaliacaofinal.model;

enum class TipoUsuario {
    USUARIO,
    ADMIN
}



