package com.example.avaliacaofinal.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.avaliacaofinal.model.Usuario
import com.example.avaliacaofinal.repository.UsuarioRepository
import androidx.lifecycle.viewModelScope
import com.example.avaliacaofinal.model.Admin
import com.example.avaliacaofinal.repository.AdminRepository
import kotlinx.coroutines.launch

class AdminViewModel(private val adminRepository: AdminRepository) : ViewModel() {

    private val _admin = MutableLiveData<Admin?>()
    val admin: LiveData<Admin?> get() = _admin

    private val _todosAdmins = MutableLiveData<List<Admin>>()
    val todosAdmins: LiveData<List<Admin>> get() = _todosAdmins

    fun salvarAdmin(admin: Admin) {
        viewModelScope.launch {
            val id = adminRepository.salvarAdmin(admin)
        }
    }

    fun getAdminByUsernameSenha(email: String, senha: String) {
        viewModelScope.launch {
            _admin.value = adminRepository.getAdminByEmailSenha(email, senha)
        }
    }

    fun getAllAdmins() {
        viewModelScope.launch {
            _todosAdmins.value = adminRepository.getAllAdmins()
        }
    }

    fun deleteAdmin(admin: Admin) {
        viewModelScope.launch {
            adminRepository.deleteAdmin(admin)
        }
    }
}
