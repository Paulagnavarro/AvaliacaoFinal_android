package com.example.avaliacaofinal.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.avaliacaofinal.R
import android.content.Intent
import android.widget.Button
import android.widget.EditText
import com.example.avaliacaofinal.model.Admin
import com.example.avaliacaofinal.model.Usuario
import com.example.avaliacaofinal.viewmodel.LoginViewModel

class LoginActivity : AppCompatActivity() {

    private lateinit var emailEditText: EditText
    private lateinit var senhaEditText: EditText
    private lateinit var loginButton: Button

    private lateinit var loginViewModel : LoginViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        emailEditText = findViewById(R.id.editTextEmail)
        senhaEditText = findViewById(R.id.editTextSenha)
        loginButton = findViewById(R.id.buttonLogin)

        loginButton.setOnClickListener {
            val email = emailEditText.text.toString()
            val senha = senhaEditText.text.toString()

            loginViewModel.fazerLogin(email, senha)
        }

        observeViewModel()
    }

    private fun observeViewModel() {
        loginViewModel.usuario.observe(this, { usuario: Usuario ->
            if (usuario != null) {
                val intent = Intent(this, MainActivityUsuario::class.java)
                startActivity(intent)
                finish()
            } else {
            }
        })

        loginViewModel.admin.observe(this, { admin: Admin ->
            if (admin != null) {
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
            } else {
            }
        })
    }
}
