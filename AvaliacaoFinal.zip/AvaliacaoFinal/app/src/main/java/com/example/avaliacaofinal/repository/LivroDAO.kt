package com.example.avaliacaofinal.repository

import androidx.room.*
import com.example.avaliacaofinal.model.Livro

@Dao
interface LivroDAO {

    @Insert
    fun salvar(livro: Livro) : Long

    @Update
    fun atualizar(livro: Livro)

    @Delete
    fun deletar (livro: Livro)

    @Query("SELECT * FROM livros WHERE id = :id")
    fun getLivro(id: Int): Livro

    @Query("SELECT * FROM livros")
    fun getAll() : List<Livro>


}