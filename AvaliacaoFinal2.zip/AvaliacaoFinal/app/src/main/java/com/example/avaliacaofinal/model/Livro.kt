package com.example.avaliacaofinal.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "livros")
data class Livro (
    @ColumnInfo @PrimaryKey(autoGenerate = true) var id: Int,
    @ColumnInfo(name = "nome_livro") var nomeLivro: String,
    @ColumnInfo var categoria: String,
    @ColumnInfo var ano: String,
    @ColumnInfo var autor: String
)