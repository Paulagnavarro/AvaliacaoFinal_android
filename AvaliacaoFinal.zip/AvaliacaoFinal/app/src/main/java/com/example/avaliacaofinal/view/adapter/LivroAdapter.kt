package com.example.avaliacaofinal.view.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.avaliacaofinal.R
import com.example.avaliacaofinal.model.Livro
import com.example.avaliacaofinal.view.viewholder.LivroViewHolder

class LivroAdapter(var context: Context): RecyclerView.Adapter<LivroViewHolder>() {

    lateinit var listaAdapter : List<Livro>
    var onItemLongClick : ((Int) -> Unit)? = null
    var onItemClick : ((Int) -> Unit)? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LivroViewHolder {
        val layout = LayoutInflater.from(context)
            .inflate(R.layout.livro_layout, parent, false)
        return LivroViewHolder(layout)
    }

    override fun onBindViewHolder(holder: LivroViewHolder, position: Int) {
        val livro = listaAdapter[position]
        val txtHolder = "${livro.nomeLivro} - categoria:${livro.categoria} / ano:${livro.ano} / autor:${livro.autor}"
        holder.txtDadosLivro.text = txtHolder
//        holder.txtCategoria.text = txtHolder
//        holder.txtAno.text = txtHolder
//        holder.txtAutor.text = txtHolder

        holder.itemView.setOnLongClickListener{
            onItemLongClick?.invoke(position)
            true
        }

        holder.itemView.setOnClickListener{
            onItemClick?.invoke(position)
        }

    }

    override fun getItemCount(): Int {
        return listaAdapter.size
    }

    fun updateAdapter(list: List<Livro>){
        listaAdapter = list
        notifyDataSetChanged()
    }
}