package com.example.avaliacaofinal.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.avaliacaofinal.model.Livro
import com.example.avaliacaofinal.model.ValidarLivro
import com.example.avaliacaofinal.repository.LivroRepository

class LivroViewModel(application: Application): AndroidViewModel(application) {

    private var repository = LivroRepository(application.applicationContext)
    private var validacao = ValidarLivro()
    private var livroFromDB = MutableLiveData<Livro>()
    private var txtToast = MutableLiveData<String>()

    fun getLivroFromDB() : LiveData<Livro> {
        return livroFromDB
    }

    fun getTxtToast(): LiveData<String> {
        return txtToast
    }

    fun findLivro(id: Int){
        livroFromDB.value = repository.getLivro(id)
    }

    fun validarAntesDeAtualizar(nomeLivro: String, categoria: String, ano: String, autor: String) : Boolean {
        if (validacao.camposEmBranco(nomeLivro, categoria, ano, autor)){
            txtToast.value = "Preencha todos os campos!"
            return false
        }

        return true
    }

    fun atualizar(livro: Livro){
        repository.atualizar(livro)
        txtToast.value = "Livro atualizado!"
    }

}