package com.example.avaliacaofinal.repository

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.avaliacaofinal.model.Livro

@Database(entities = [Livro::class], version = 1)
abstract class LivroDataBase : RoomDatabase(){

    abstract fun getDAO() : LivroDAO

    companion object{
        private lateinit var INSTANCE: LivroDataBase
        fun getInstace(context: Context): LivroDataBase {
            if(!::INSTANCE.isInitialized){
                INSTANCE = Room.databaseBuilder(context, LivroDataBase::class.java, "livros_db")
                    .allowMainThreadQueries()
                    .build()
            }
            return INSTANCE
        }
    }
}