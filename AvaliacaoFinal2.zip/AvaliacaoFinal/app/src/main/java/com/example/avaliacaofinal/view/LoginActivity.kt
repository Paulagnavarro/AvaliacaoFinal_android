package com.example.avaliacaofinal.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.avaliacaofinal.R

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import com.example.avaliacaofinal.viewmodel.LoginViewModel
import com.example.avaliacaofinal.viewmodel.TipoUsuario

class LoginActivity : AppCompatActivity() {

    private lateinit var emailEditText: EditText
    private lateinit var senhaEditText: EditText
    private lateinit var loginButton: Button

    private val loginViewModel = LoginViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        emailEditText = findViewById(R.id.editTextEmail)
        senhaEditText = findViewById(R.id.editTextSenha)
        loginButton = findViewById(R.id.buttonLogin)

        loginButton.setOnClickListener {
            val email = emailEditText.text.toString()
            val senha = senhaEditText.text.toString()

            // Aqui você faz a chamada para o ViewModel para realizar o login
            loginViewModel.fazerLogin(email, senha, TipoUsuario.USUARIO)
            // Ou para admin
            // loginViewModel.fazerLogin(email, senha, TipoUsuario.ADMIN)
        }

        observeViewModel()
    }

    private fun observeViewModel() {
        loginViewModel.usuario.observe(this, { usuario ->
            if (usuario != null) {
                // Login bem-sucedido como usuário, redireciona para a atividade do usuário
                val intent = Intent(this, UsuarioActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                // Tratar login falhado para usuário
            }
        })

        loginViewModel.admin.observe(this, { admin ->
            if (admin != null) {
                // Login bem-sucedido como admin, redireciona para a atividade do admin
                val intent = Intent(this, AdminActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                // Tratar login falhado para admin
            }
        })
    }
}
