package com.example.avaliacaofinal.view.viewholder

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.avaliacaofinal.R

class LivroViewHolder(layout: View): RecyclerView.ViewHolder(layout) {

    var txtDadosLivro = layout.findViewById<TextView>(R.id.txtDadosLivro)

}